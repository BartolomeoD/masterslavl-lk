var app = angular.module('plunker', []);

app.controller('MainCtrl', function($scope, countDays) {
	$scope.days=3;
	$scope.name = "Иван",
	$scope.week=['пн','вт','ср','чт','пт','сб','вс'],
	$scope.date= new Date();
	$scope.month=$scope.date.getMonth();
	$scope.months=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
	$scope.days=123;
	$scope.days=countDays.count($scope.date);
	$scope.firstDay=countDays.first($scope.date);
	$scope.next = function(){
		$scope.days=countDays.count($scope.date);
		$scope.firstDay=countDays.first($scope.date);
		$scope.month=$scope.date.getMonth();
		}
	$scope.table=new Array();
	$scope.testDate = new Date().getTimezoneOffset();
	dateForCal= new Date($scope.date.getFullYear(), $scope.date.getMonth(),0);
	var count=0;
	for(i=0;i<6;i++){
		$scope.table[i]=new Array;
		for(j=0;j<7;j++){
				$scope.table[i][j]=count;
				count++;
		}
	}
  
});

app.factory('countDays', function() {
    return { count:  function(date) {
				return 32 - new Date(date.getFullYear(), date.getMonth(), 32).getDate();
				},
				
			 first: function(date){
					firstDay= new Date(date.getFullYear(), date.getMonth(), 1);
					return firstDay=firstDay.getDay();
					}
			}
		}
	
);

        
    

